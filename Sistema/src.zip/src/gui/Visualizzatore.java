package gui;

import java.io.IOException;

public interface Visualizzatore {

	public void caricaPannelloDati() throws ClassNotFoundException, IOException;
}
