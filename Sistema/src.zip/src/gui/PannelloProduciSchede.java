package gui;

import javax.swing.JPanel;

public class PannelloProduciSchede extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
